<?php
//incluir archivo de conexion a la base de datos
require_once "conexion.php";
//definir variables e inicializar con valores vacio
$username = $password = $email = "";
$username_error = $password_error = $email_error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty(trin($_POST["username"]))){
        $username_error = "Debe ingresar un nombre valido"
    }

}

?>