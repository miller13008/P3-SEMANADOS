<?php

define('db_server', 'localhost');
define('db_name', 'usuario');
define('db_username', 'root');
define('db_password', '');

$conexion=mysqli_connect('db_server', 'db_name', 'db_username','db_password');
    mysqli_set_charset($conexion,"utf8");}
    if($conexion === false){
        die("no se pudo conetar" . mysqli_connect_error());
    }else{
        echo 'se ha conectado';
    }
?>