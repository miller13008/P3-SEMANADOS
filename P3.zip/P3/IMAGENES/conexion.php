<?php

define('db_server', 'miguel');
define('db_name', 'gym');
define('db_username', 'miguel');
define('db_password', 'miguel');

$conexion=mysqli_connect('db_server', 'db_name', 'db_username','db_password');
    mysqli_set_charset($conexion,"utf8");}
    if($conexion === false){
        die("no se pudo conetar" . mysqli_connect_error());
    }else{
        echo 'se ha conectado';
    }
?>